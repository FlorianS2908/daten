Tag 5 Paket – Bedingungen & Logik

Enthalten:
- 4 Dozent-Notebooks
- 4 Teilnehmer-Notebooks
- 4 Lösungs-Notebooks
- 4 Dozenten-PowerPoints im CF-Umschulung-Layout

Hinweise:
- Navigierbares Inhaltsverzeichnis am Anfang jedes Notebooks
- Lernhöhe 1 / Lernhöhe 2 / Lernhöhe 3
- Online-Quellen und Buchreferenzen
- Projektraum Klemmbausteine GmbH nur mit Aufgaben, die in den Stufenunterlagen ausdrücklich mit Tag 5 gekennzeichnet sind
- Grundlage: Trainer-Handout LF05, Tag 5, sowie Aufgaben Projekt Stufe 1, Tag 5