Tag 3 – Komplettpaket

Enthalten:
- 5 Dozenten-Notebooks
- 5 Teilnehmer-Notebooks
- 5 Lösungs-Notebooks
- 5 Dozenten-PowerPoints im CF-Umschulung-Layout

Themen aus Tag 3:
1. Variablen und Datentypen
2. Operatoren und Ausdrücke
3. Strings: Grundlagen
4. Debugging (Grundidee)
5. PAP als lineares Rechenmodell

Umsetzung:
- Aufgaben in Lernhöhe 1, Lernhöhe 2 und Lernhöhe 3
- Navigierbares Inhaltsverzeichnis am Anfang der Dozenten- und Teilnehmer-Notebooks
- Trennlinie nach jedem Block
- Ausführliche Beispiele
- Online-Quellen und Buchreferenzen integriert
- PowerPoints auf Basis der Vorlage CF_Umschulung_Vorlage_PPTs.pptx
- Inhaltlich an Tag 3 des Trainer-Handouts orientiert
