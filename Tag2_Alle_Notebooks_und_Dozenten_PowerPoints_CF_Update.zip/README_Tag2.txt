Tag 2 – Komplettpaket

Enthalten:
- 4 Dozenten-Notebooks
- 4 Teilnehmer-Notebooks
- 4 Lösungs-Notebooks
- 4 Dozenten-PowerPoints im CF-Umschulung-Layout

Themen aus Tag 2:
1. Algorithmus vs. Programm
2. Entscheidungstabellen
3. Darstellungsmethoden: Pseudocode, PAP und Struktogramm
4. Use Case als Brücke zur Domäne

Umsetzung:
- Aufgaben in Lernhöhe 1, Lernhöhe 2 und Lernhöhe 3
- Navigierbares Inhaltsverzeichnis am Anfang der Dozenten- und Teilnehmer-Notebooks
- Trennlinie nach jedem Block
- Ausführliche Beispiele
- Online-Quellen und Buchreferenzen integriert
- PowerPoints auf Basis der Vorlage CF_Umschulung_Vorlage_PPTs.pptx
- Inhaltlich an Tag 2 des Trainer-Handouts orientiert
