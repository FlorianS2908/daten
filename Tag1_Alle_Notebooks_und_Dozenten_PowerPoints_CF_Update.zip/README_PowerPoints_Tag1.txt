Ergänzung zum Paket:

Enthalten sind 4 PowerPoints für die Dozenten-Notebooks von Tag 1,
angelegt im Layout der Vorlage "CF_Umschulung_Vorlage_PPTs.pptx".

Inhaltliche Grundlage:
- Trainer-Handout LF05, Tag 1
- jeder Foliensatz ist einem Dozenten-Notebook zugeordnet
- die Platzhalterlogik "Storyboard" wurde inhaltlich mit dem Trainer-Handout gefüllt

Dateien:
- Tag1_01_Softwareverstaendnis_Dozent_Praesentation.pptx
- Tag1_02_Berufsbild_FISI_FIAE_Dozent_Praesentation.pptx
- Tag1_03_Programm_und_Programmierung_Dozent_Praesentation.pptx
- Tag1_04_Arbeitsumgebung_Jupyter_VSCode_Dozent_Praesentation.pptx
