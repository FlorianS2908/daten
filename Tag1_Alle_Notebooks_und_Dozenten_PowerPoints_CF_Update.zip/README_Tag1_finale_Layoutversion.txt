Tag-1-Paket im final angepassten Layout

Enthalten:
- 4 Dozent-Notebooks
- 4 Teilnehmer-Notebooks
- 4 Lösungs-Notebooks
- 4 Dozenten-PowerPoints

Aktuelle Anpassungen:
- Aufgabenstufen wurden in Lernhöhe 1, Lernhöhe 2 und Lernhöhe 3 umbenannt
- Dozenten-PowerPoints wurden auf die Vorlage "CF_Umschulung_Vorlage_PPTs.pptx" umgestellt
- die PowerPoints orientieren sich inhaltlich am Trainer-Handout für Tag 1
