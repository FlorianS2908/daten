<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stadt eingeben</title>
</head>
<body>
    <h1>1. Stadt eingeben</h1>

    <?php if (isset($_GET["fehler"]) && $_GET["fehler"] === "stadt") { ?>
        <p role="alert"><strong>Bitte gib eine Stadt als Text ein. Das Feld darf nicht leer sein.</strong></p>
    <?php } ?>

    <!-- Bewusst ohne required: Die Prüfung soll hier in PHP stattfinden. -->
    <form action="auswahl.php" method="post">
        <label for="stadt">Stadt:</label>
        <input type="text" id="stadt" name="stadt">
        <button type="submit">Zum zweiten Formular</button>
    </form>
</body>
</html>
