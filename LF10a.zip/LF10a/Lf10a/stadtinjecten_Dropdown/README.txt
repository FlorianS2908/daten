LF10a – Stadt aus einem Formular in ein zweites Formular übernehmen

Keine Datenbank, keine Session, kein JavaScript.
Pro Durchlauf wird genau eine Stadt übernommen. Es werden keine Städte gesammelt.

START
Ordner LF10a_Stadt_Dropdown nach C:\xampp\htdocs entpacken.
Apache starten. MySQL wird nicht benötigt.
Im Browser öffnen:
http://localhost/LF10a_Stadt_Dropdown/index.php

DATEIEN
index.php     – Erstes Formular: Stadt eingeben; mögliche Fehlermeldung anzeigen.
auswahl.php   – POST-Eintrag prüfen und das zweite Formular mit Dropdown ausgeben.
ergebnis.php  – Bestätigte Auswahl erneut prüfen und als Text ausgeben.

ABLAUF
1. Zum Beispiel "  Hamburg  " eingeben und absenden.
2. PHP prüft isset(), is_string() und den Inhalt nach trim().
3. Das zweite Formular zeigt Hamburg als eine Option im Dropdown.
4. "Auswahl bestätigen" zeigt Hamburg auf der Ergebnisseite.

FEHLER TESTEN
- Eingabe leer lassen oder nur normale Leerzeichen eingeben.
  Erwartung: Rückleitung zu index.php, Meldung, leeres Eingabefeld.
- auswahl.php ohne vorherige Formulareingabe direkt öffnen.
  Erwartung: dieselbe kontrollierte Rückleitung.
- Stadt "Bad Homburg" oder "München" eingeben.
  Erwartung: vollständiger Text einschließlich Leerzeichen bzw. Umlaut.

WICHTIG
Die Stadt wird über POST an die nächste PHP-Datei übertragen.
PHP erzeugt dort das HTML samt option-Element neu. Es verändert nicht nachträglich
mit JavaScript das erste Formular im Browser.

Die kleine Prüfung verlangt nur einen nicht leeren Text. Sie prüft NICHT, ob die
Stadt geografisch existiert. Ohne zusätzliche Speicherung wird auch NICHT geprüft,
ob ein manipuliertes zweites Formular noch denselben Stadtnamen sendet.
htmlspecialchars() sorgt für die passende HTML-Ausgabe; es ersetzt keine Inhaltsprüfung.
Die Fehler-Rückleitung muss vor jeder HTML-Ausgabe stehen; anschließend folgt exit.
Ein erneutes Öffnen von index.php beginnt einen neuen Durchlauf ohne gespeicherte Stadt.

TECHNISCHE REFERENZEN
PHP – Formulare: https://www.php.net/manual/de/tutorial.forms.php
PHP – header: https://www.php.net/manual/de/function.header.php
PHP – htmlspecialchars: https://www.php.net/manual/de/function.htmlspecialchars.php
