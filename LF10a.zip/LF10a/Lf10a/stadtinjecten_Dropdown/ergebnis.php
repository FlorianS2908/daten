<?php
// Auch Daten aus einem Dropdown werden erneut geprüft.
if (!isset($_POST["stadt"]) || !is_string($_POST["stadt"])) {
    header("Location: index.php?fehler=stadt", true, 303);
    exit;
}

$stadt = trim($_POST["stadt"]);

if ($stadt === "") {
    header("Location: index.php?fehler=stadt", true, 303);
    exit;
}

$stadtHtml = htmlspecialchars($stadt, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8");
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gewählte Stadt</title>
</head>
<body>
    <h1>Gewählte Stadt</h1>
    <p>Du hast <strong><?= $stadtHtml ?></strong> ausgewählt.</p>
    <p><a href="index.php">Neu beginnen</a></p>
</body>
</html>
