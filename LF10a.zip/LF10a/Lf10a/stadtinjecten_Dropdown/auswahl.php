<?php
// 1. Prüfen, ob der einzelne POST-Eintrag vorhanden und ein Text ist.
if (!isset($_POST["stadt"]) || !is_string($_POST["stadt"])) {
    header("Location: index.php?fehler=stadt", true, 303);
    exit;
}

// 2. Äußere Leerzeichen entfernen und eine leere Eingabe ablehnen.
$stadt = trim($_POST["stadt"]);

if ($stadt === "") {
    header("Location: index.php?fehler=stadt", true, 303);
    exit;
}

// 3. Für HTML-Text und das value-Attribut maskieren.
$stadtHtml = htmlspecialchars($stadt, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8");
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stadt auswählen</title>
</head>
<body>
    <h1>2. Stadt auswählen</h1>

    <form action="ergebnis.php" method="post">
        <label for="auswahl">Übernommene Stadt:</label>
        <select id="auswahl" name="stadt">
            <!-- Die geprüfte Stadt wird als auswählbarer Eintrag eingesetzt. -->
            <option value="<?= $stadtHtml ?>"><?= $stadtHtml ?></option>
        </select>
        <button type="submit">Auswahl bestätigen</button>
    </form>

    <p><a href="index.php">Andere Stadt eingeben</a></p>
</body>
</html>
