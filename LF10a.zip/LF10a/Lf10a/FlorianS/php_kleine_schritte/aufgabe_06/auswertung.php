<?php
// Aufgabe 06: Dropdown-Wert nachschlagen
// $ziel sowie der Katalog $ziele mit Berlin, Paris und Rom sind fertig.
$ausgabe = "";

// VORBEREITET: Eingabewerte für diese einzelne Aufgabe.
$ziel = $_GET["ziel"] ?? "";
if (!is_string($ziel)) {
    $ziel = "";
}
$ziele = ["berlin" => "Berlin", "paris" => "Paris", "rom" => "Rom"];

// ===== AB HIER ARBEITEN =====
// TODO: Bearbeite hier die Aufgabe.
// ===== BIS HIER ARBEITEN =====
?>
<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Aufgabe 06 · Auswertung · LF10a</title>
  <link rel="stylesheet" href="style.css">
</head>
<body><main class="wrap">
  <div class="topline"><span class="brand">LF10a · PHP-BASIS</span><span class="badge">Aufgabe 06</span></div>
  <header class="hero"><h1>Die PHP-Auswertung</h1><p>Dropdown-Wert nachschlagen</p></header>
  <section class="card" aria-labelledby="ergebnis">
    <h2 id="ergebnis">Dein Ergebnis</h2>
    <!-- Fertige Textausgabe: nicht ändern. Kein HTML in $ausgabe schreiben. -->
    <pre class="output"><?= htmlspecialchars($ausgabe, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8") ?></pre>
    <a class="button" href="formular.html">Zurück zum Formular</a>
    <p class="hint">Zurück öffnet die festen Beispielwerte erneut. Es wird nichts gespeichert.</p>
  </section>
  <footer><a href="../index.html">Zur Aufgabenübersicht</a> · Arbeitsdatei</footer>
</main></body>
</html>
